export interface Recipe {
  id: string
  title: string
  description: string
  ingredients: string[]
  instructions: string[]
  cookingTime: number
  difficulty: "easy" | "medium" | "hard"
  servings: number
  category: string
  tags: string[]
  authorId: string
  createdAt: string
  updatedAt: string
  imageUrl?: string
}

export const mockRecipes: Recipe[] = [
  {
    id: "1",
    title: "Klassikaline Borš",
    description: "Traditsiooniline Vene peedisüpp koos lihaga ja hapukoorega",
    ingredients: [
      "500g veiseliha",
      "3 keskmist peeti",
      "2 porgandit",
      "1 sibul",
      "3 kartulid",
      "200g kapsa",
      "2 tl tomatipastet",
      "Hapukoor serveerimiseks",
    ],
    instructions: [
      "Keeda liha 1,5 tundi kuni pehme",
      "Riivi peet ja porgand",
      "Praadi köögiviljad õlis",
      "Lisa keedetud liha juurde",
      "Keeda 30 minutit",
      "Serveeri hapukoorega",
    ],
    cookingTime: 120,
    difficulty: "medium",
    servings: 6,
    category: "Supid",
    tags: ["traditsiooniline", "talveroog", "liha"],
    authorId: "3",
    createdAt: "2024-01-15T10:00:00.000Z",
    updatedAt: "2024-01-15T10:00:00.000Z",
    imageUrl: "/traditional-borscht-soup.jpg",
  },
  {
    id: "2",
    title: "Eesti Kartulisalat",
    description: "Kodune kartulisalat singi ja munadega",
    ingredients: ["1kg kartuleid", "4 keedetud muna", "200g sinki", "2 kurki", "1 sibul", "Majonees", "Sool ja pipar"],
    instructions: [
      "Keeda kartulid koorega",
      "Lõika kõik koostisosad kuubikuteks",
      "Sega majonees alla",
      "Maitsesta soola ja pipraga",
      "Lase külmkapis seista 2 tundi",
    ],
    cookingTime: 45,
    difficulty: "easy",
    servings: 8,
    category: "Salatid",
    tags: ["eesti", "külm", "peoroog"],
    authorId: "2",
    createdAt: "2024-01-20T14:30:00.000Z",
    updatedAt: "2024-01-20T14:30:00.000Z",
    imageUrl: "/estonian-potato-salad.jpg",
  },
  {
    id: "3",
    title: "Pannkoogid Maasikatega",
    description: "Õhulised pannkoogid värskete marjadega",
    ingredients: [
      "2 tassi jahu",
      "2 muna",
      "1,5 tassi piima",
      "2 sl suhkrut",
      "1 tl küpsetuspulbrit",
      "Värskeid maasikaid",
      "Mesi või siirup",
    ],
    instructions: [
      "Sega kuivad koostisosad",
      "Lisa munad ja piim",
      "Sega sile taignaks",
      "Küpseta pannkoogid pannilt",
      "Serveeri marjade ja meega",
    ],
    cookingTime: 25,
    difficulty: "easy",
    servings: 4,
    category: "Magustoidud",
    tags: ["hommikusöök", "magus", "kiire"],
    authorId: "1",
    createdAt: "2024-01-25T08:15:00.000Z",
    updatedAt: "2024-01-25T08:15:00.000Z",
    imageUrl: "/pancakes-with-strawberries.jpg",
  },
]
