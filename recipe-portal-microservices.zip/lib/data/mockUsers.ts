export interface User {
  id: string
  email: string
  password: string
  name: string
  createdAt: string
  updatedAt: string
}

export const mockUsers: User[] = [
  {
    id: "1",
    email: "admin@example.com",
    password: "$2b$10$rOzJqQqZQqZQqZQqZQqZQeJ1J1J1J1J1J1J1J1J1J1J1J1J1J1J1J", // password: admin123
    name: "Admin User",
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "2",
    email: "user@example.com",
    password: "$2b$10$rOzJqQqZQqZQqZQqZQqZQeJ1J1J1J1J1J1J1J1J1J1J1J1J1J1J1J", // password: user123
    name: "Regular User",
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: "3",
    email: "chef@example.com",
    password: "$2b$10$rOzJqQqZQqZQqZQqZQqZQeJ1J1J1J1J1J1J1J1J1J1J1J1J1J1J1J", // password: chef123
    name: "Chef Maria",
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
]
