"use client"

import { Header } from "../frontend/components/layout/Header"

export default function SyntheticV0PageForDeployment() {
  return <Header />
}