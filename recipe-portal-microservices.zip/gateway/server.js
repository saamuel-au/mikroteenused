const express = require("express")
const cors = require("cors")
const { createProxyMiddleware } = require("http-proxy-middleware")

const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.json())

// Health check endpoint
app.get("/health", (req, res) => {
  res.json({
    status: "OK",
    message: "API Gateway is running",
    timestamp: new Date().toISOString(),
  })
})

// Service URLs from environment variables
const USERS_SERVICE_URL = process.env.USERS_SERVICE_URL || "http://localhost:3001"
const RECIPES_SERVICE_URL = process.env.RECIPES_SERVICE_URL || "http://localhost:3002"
const SEARCH_SERVICE_URL = process.env.SEARCH_SERVICE_URL || "http://localhost:3003"
const RATINGS_SERVICE_URL = process.env.RATINGS_SERVICE_URL || "http://localhost:3004"

// Proxy configuration
const proxyOptions = {
  changeOrigin: true,
  logLevel: "debug",
  onError: (err, req, res) => {
    console.error("Proxy error:", err)
    res.status(500).json({
      error: "Service unavailable",
      message: "The requested service is currently unavailable",
    })
  },
  onProxyReq: (proxyReq, req, res) => {
    console.log(`Proxying ${req.method} ${req.url} to ${proxyReq.path}`)
  },
}

// Route to Users Service
app.use(
  "/api/users",
  createProxyMiddleware({
    target: USERS_SERVICE_URL,
    pathRewrite: {
      "^/api/users": "/api/users",
    },
    ...proxyOptions,
  }),
)

// Route to Recipes Service
app.use(
  "/api/recipes",
  createProxyMiddleware({
    target: RECIPES_SERVICE_URL,
    pathRewrite: {
      "^/api/recipes": "/api/recipes",
    },
    ...proxyOptions,
  }),
)

// Route to Search Service
app.use(
  "/api/search",
  createProxyMiddleware({
    target: SEARCH_SERVICE_URL,
    pathRewrite: {
      "^/api/search": "/api/search",
    },
    ...proxyOptions,
  }),
)

// Route to Ratings Service
app.use(
  "/api/ratings",
  createProxyMiddleware({
    target: RATINGS_SERVICE_URL,
    pathRewrite: {
      "^/api/ratings": "/api/ratings",
    },
    ...proxyOptions,
  }),
)

// Default route for API documentation
app.get("/api", (req, res) => {
  res.json({
    message: "Recipe Portal API Gateway",
    version: "1.0.0",
    services: {
      users: `${USERS_SERVICE_URL}/api/users`,
      recipes: `${RECIPES_SERVICE_URL}/api/recipes`,
      search: `${SEARCH_SERVICE_URL}/api/search`,
      ratings: `${RATINGS_SERVICE_URL}/api/ratings`,
    },
    endpoints: {
      users: [
        "POST /api/users/register - Register new user",
        "POST /api/users/login - User login",
        "GET /api/users/profile - Get user profile (requires auth)",
      ],
      recipes: [
        "GET /api/recipes - Get all recipes",
        "GET /api/recipes/:id - Get recipe by ID",
        "POST /api/recipes - Create new recipe (requires auth)",
        "PUT /api/recipes/:id - Update recipe (requires auth)",
        "DELETE /api/recipes/:id - Delete recipe (requires auth)",
      ],
      search: ["GET /api/search?q=keyword - Search recipes by keyword"],
      ratings: [
        "GET /api/ratings/recipe/:recipeId - Get ratings for recipe",
        "POST /api/ratings - Add rating (requires auth)",
        "GET /api/ratings/comments/:recipeId - Get comments for recipe",
        "POST /api/ratings/comments - Add comment (requires auth)",
      ],
    },
  })
})

// 404 handler
app.use("*", (req, res) => {
  res.status(404).json({
    error: "Not Found",
    message: `Route ${req.originalUrl} not found`,
    availableRoutes: ["/api", "/api/users", "/api/recipes", "/api/search", "/api/ratings"],
  })
})

// Error handler
app.use((err, req, res, next) => {
  console.error("Gateway error:", err)
  res.status(500).json({
    error: "Internal Server Error",
    message: "Something went wrong in the API Gateway",
  })
})

app.listen(PORT, () => {
  console.log(`🚀 API Gateway running on port ${PORT}`)
  console.log(`📋 API Documentation available at http://localhost:${PORT}/api`)
  console.log(`🔍 Health check at http://localhost:${PORT}/health`)
  console.log("\n📡 Service URLs:")
  console.log(`   Users: ${USERS_SERVICE_URL}`)
  console.log(`   Recipes: ${RECIPES_SERVICE_URL}`)
  console.log(`   Search: ${SEARCH_SERVICE_URL}`)
  console.log(`   Ratings: ${RATINGS_SERVICE_URL}`)
})
