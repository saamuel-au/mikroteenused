import { Suspense } from "react"
import { Header } from "@/components/layout/Header"
import { Hero } from "@/components/home/Hero"
import { FeaturedRecipes } from "@/components/home/FeaturedRecipes"
import { SearchSection } from "@/components/home/SearchSection"
import { Footer } from "@/components/layout/Footer"
import { LoadingSpinner } from "@/components/ui/loading-spinner"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <SearchSection />
        <Suspense fallback={<LoadingSpinner />}>
          <FeaturedRecipes />
        </Suspense>
      </main>
      <Footer />
    </div>
  )
}
