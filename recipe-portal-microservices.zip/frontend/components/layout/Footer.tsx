import Link from "next/link"
import { ChefHat, Github, Twitter, Instagram } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-muted/30 border-t">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <ChefHat className="h-6 w-6 text-primary" />
              <span className="text-lg font-bold">RecipePortal</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Discover and share amazing recipes from around the world. Join our community of food lovers.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <Twitter className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <Instagram className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <Github className="h-5 w-5" />
              </Link>
            </div>
          </div>

          {/* Recipes */}
          <div className="space-y-4">
            <h3 className="font-semibold">Recipes</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/recipes" className="text-muted-foreground hover:text-foreground">
                  Browse All
                </Link>
              </li>
              <li>
                <Link href="/search?category=italian" className="text-muted-foreground hover:text-foreground">
                  Italian
                </Link>
              </li>
              <li>
                <Link href="/search?category=dessert" className="text-muted-foreground hover:text-foreground">
                  Desserts
                </Link>
              </li>
              <li>
                <Link href="/search?difficulty=easy" className="text-muted-foreground hover:text-foreground">
                  Easy Recipes
                </Link>
              </li>
            </ul>
          </div>

          {/* Community */}
          <div className="space-y-4">
            <h3 className="font-semibold">Community</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/register" className="text-muted-foreground hover:text-foreground">
                  Join Us
                </Link>
              </li>
              <li>
                <Link href="/recipes/new" className="text-muted-foreground hover:text-foreground">
                  Share Recipe
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Guidelines
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Help
                </Link>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div className="space-y-4">
            <h3 className="font-semibold">Company</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  About
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Privacy
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Terms
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 RecipePortal. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
