const express = require("express")
const cors = require("cors")
const axios = require("axios")

const app = express()
const PORT = process.env.PORT || 3003
const RECIPES_SERVICE_URL = process.env.RECIPES_SERVICE_URL || "http://localhost:3002"

// Middleware
app.use(cors())
app.use(express.json())

// Mock search index for better performance (in real app, this would be Elasticsearch or similar)
let searchIndex = []
let lastIndexUpdate = null

// Helper functions
const updateSearchIndex = async () => {
  try {
    console.log("Updating search index...")
    const response = await axios.get(`${RECIPES_SERVICE_URL}/api/recipes?limit=1000`)
    const recipes = response.data.recipes || []

    // Create search index with tokenized content
    searchIndex = recipes.map((recipe) => ({
      id: recipe.id,
      title: recipe.title.toLowerCase(),
      description: recipe.description.toLowerCase(),
      ingredients: recipe.ingredients.map((ing) => ing.toLowerCase()),
      category: recipe.category.toLowerCase(),
      tags: recipe.tags.map((tag) => tag.toLowerCase()),
      authorName: recipe.authorName.toLowerCase(),
      difficulty: recipe.difficulty.toLowerCase(),
      // Combined searchable text
      searchText: [
        recipe.title,
        recipe.description,
        ...recipe.ingredients,
        recipe.category,
        ...recipe.tags,
        recipe.authorName,
        recipe.difficulty,
      ]
        .join(" ")
        .toLowerCase(),
      // Original recipe data
      recipe,
    }))

    lastIndexUpdate = new Date()
    console.log(`Search index updated with ${searchIndex.length} recipes`)
  } catch (error) {
    console.error("Failed to update search index:", error.message)
  }
}

const searchRecipes = (query, filters = {}) => {
  if (!query || query.trim().length === 0) {
    return searchIndex.map((item) => item.recipe)
  }

  const searchTerms = query
    .toLowerCase()
    .split(" ")
    .filter((term) => term.length > 0)

  let results = searchIndex.filter((item) => {
    // Check if all search terms are found in the searchable text
    return searchTerms.every((term) => item.searchText.includes(term))
  })

  // Apply filters
  if (filters.category) {
    results = results.filter((item) => item.category === filters.category.toLowerCase())
  }

  if (filters.difficulty) {
    results = results.filter((item) => item.difficulty === filters.difficulty.toLowerCase())
  }

  if (filters.tags && filters.tags.length > 0) {
    const filterTags = filters.tags.map((tag) => tag.toLowerCase())
    results = results.filter((item) => filterTags.some((tag) => item.tags.includes(tag)))
  }

  if (filters.author) {
    results = results.filter((item) => item.authorName.includes(filters.author.toLowerCase()))
  }

  // Score results based on relevance
  results = results.map((item) => {
    let score = 0

    searchTerms.forEach((term) => {
      // Higher score for matches in title
      if (item.title.includes(term)) score += 10

      // Medium score for matches in description
      if (item.description.includes(term)) score += 5

      // Lower score for matches in ingredients
      if (item.ingredients.some((ing) => ing.includes(term))) score += 3

      // Lower score for matches in tags
      if (item.tags.some((tag) => tag.includes(term))) score += 2

      // Lowest score for matches in other fields
      if (item.category.includes(term) || item.authorName.includes(term)) score += 1
    })

    return {
      ...item,
      relevanceScore: score,
    }
  })

  // Sort by relevance score (highest first)
  results.sort((a, b) => b.relevanceScore - a.relevanceScore)

  return results.map((item) => item.recipe)
}

// Initialize search index on startup
updateSearchIndex()

// Update search index every 5 minutes
setInterval(updateSearchIndex, 5 * 60 * 1000)

// Routes

// Health check
app.get("/health", (req, res) => {
  res.json({
    status: "OK",
    service: "Search Service",
    timestamp: new Date().toISOString(),
    indexSize: searchIndex.length,
    lastIndexUpdate,
  })
})

// Search recipes
app.get("/api/search", async (req, res) => {
  try {
    const { q, category, difficulty, tags, author, limit, offset } = req.query

    if (!q || q.trim().length === 0) {
      return res.status(400).json({
        error: "Validation error",
        message: "Search query (q) is required",
      })
    }

    // Prepare filters
    const filters = {}
    if (category) filters.category = category
    if (difficulty) filters.difficulty = difficulty
    if (tags) filters.tags = Array.isArray(tags) ? tags : [tags]
    if (author) filters.author = author

    // Perform search
    const results = searchRecipes(q.trim(), filters)

    // Apply pagination
    const limitNum = Number.parseInt(limit) || 10
    const offsetNum = Number.parseInt(offset) || 0
    const paginatedResults = results.slice(offsetNum, offsetNum + limitNum)

    res.json({
      query: q.trim(),
      results: paginatedResults,
      total: results.length,
      limit: limitNum,
      offset: offsetNum,
      filters: filters,
      searchTime: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Search error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to perform search",
    })
  }
})

// Search suggestions/autocomplete
app.get("/api/search/suggestions", (req, res) => {
  try {
    const { q, limit } = req.query

    if (!q || q.trim().length < 2) {
      return res.json({
        suggestions: [],
      })
    }

    const query = q.toLowerCase().trim()
    const limitNum = Number.parseInt(limit) || 5

    // Get suggestions from titles, ingredients, and tags
    const suggestions = new Set()

    searchIndex.forEach((item) => {
      // Title suggestions
      if (item.title.includes(query)) {
        suggestions.add(item.recipe.title)
      }

      // Ingredient suggestions
      item.ingredients.forEach((ingredient) => {
        if (ingredient.includes(query)) {
          // Extract the ingredient name (remove quantities)
          const cleanIngredient = ingredient.replace(/^\d+\w*\s*/, "").trim()
          if (cleanIngredient.length > 2) {
            suggestions.add(cleanIngredient)
          }
        }
      })

      // Tag suggestions
      item.tags.forEach((tag) => {
        if (tag.includes(query)) {
          suggestions.add(tag)
        }
      })

      // Category suggestions
      if (item.category.includes(query)) {
        suggestions.add(item.recipe.category)
      }
    })

    const suggestionArray = Array.from(suggestions)
      .slice(0, limitNum)
      .sort((a, b) => a.length - b.length) // Shorter suggestions first

    res.json({
      query: q.trim(),
      suggestions: suggestionArray,
    })
  } catch (error) {
    console.error("Suggestions error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get suggestions",
    })
  }
})

// Popular search terms
app.get("/api/search/popular", (req, res) => {
  try {
    // In a real app, this would track actual search queries
    // For now, return popular terms based on recipe data
    const popularTerms = []

    // Get most common tags
    const tagCounts = {}
    searchIndex.forEach((item) => {
      item.tags.forEach((tag) => {
        tagCounts[tag] = (tagCounts[tag] || 0) + 1
      })
    })

    // Get most common categories
    const categoryCounts = {}
    searchIndex.forEach((item) => {
      categoryCounts[item.category] = (categoryCounts[item.category] || 0) + 1
    })

    // Combine and sort
    const allTerms = [
      ...Object.entries(tagCounts).map(([term, count]) => ({ term, count, type: "tag" })),
      ...Object.entries(categoryCounts).map(([term, count]) => ({ term, count, type: "category" })),
    ]

    allTerms.sort((a, b) => b.count - a.count)

    res.json({
      popularTerms: allTerms.slice(0, 10),
      totalRecipes: searchIndex.length,
    })
  } catch (error) {
    console.error("Popular terms error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get popular terms",
    })
  }
})

// Force index update (for development)
app.post("/api/search/reindex", async (req, res) => {
  try {
    await updateSearchIndex()
    res.json({
      message: "Search index updated successfully",
      indexSize: searchIndex.length,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Reindex error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to update search index",
    })
  }
})

// Error handler
app.use((err, req, res, next) => {
  console.error("Search service error:", err)
  res.status(500).json({
    error: "Internal Server Error",
    message: "Something went wrong in the Search service",
  })
})

// 404 handler
app.use("*", (req, res) => {
  res.status(404).json({
    error: "Not Found",
    message: `Route ${req.originalUrl} not found in Search service`,
  })
})

app.listen(PORT, () => {
  console.log(`🔍 Search Service running on port ${PORT}`)
  console.log(`📋 Available endpoints:`)
  console.log(`   GET /api/search?q=query - Search recipes`)
  console.log(`   GET /api/search/suggestions?q=query - Get search suggestions`)
  console.log(`   GET /api/search/popular - Get popular search terms`)
  console.log(`   POST /api/search/reindex - Force index update`)
  console.log(`\n🔗 Connected to Recipes Service: ${RECIPES_SERVICE_URL}`)
  console.log(`📊 Search index will update every 5 minutes`)
})
