// Search utility functions

/**
 * Tokenize text for better search matching
 */
const tokenizeText = (text) => {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, " ") // Replace punctuation with spaces
    .split(/\s+/) // Split on whitespace
    .filter((token) => token.length > 1) // Remove single characters
}

/**
 * Calculate similarity between two strings using Jaccard similarity
 */
const calculateSimilarity = (str1, str2) => {
  const tokens1 = new Set(tokenizeText(str1))
  const tokens2 = new Set(tokenizeText(str2))

  const intersection = new Set([...tokens1].filter((x) => tokens2.has(x)))
  const union = new Set([...tokens1, ...tokens2])

  return intersection.size / union.size
}

/**
 * Extract keywords from recipe data
 */
const extractKeywords = (recipe) => {
  const keywords = new Set()

  // Add title words
  tokenizeText(recipe.title).forEach((word) => keywords.add(word))

  // Add description words (excluding common words)
  const commonWords = new Set(["the", "and", "or", "but", "in", "on", "at", "to", "for", "of", "with", "by"])
  tokenizeText(recipe.description)
    .filter((word) => !commonWords.has(word) && word.length > 2)
    .forEach((word) => keywords.add(word))

  // Add ingredient keywords
  recipe.ingredients.forEach((ingredient) => {
    // Remove quantities and measurements
    const cleanIngredient = ingredient.replace(/^\d+\s*\w*\s*/, "").trim()
    tokenizeText(cleanIngredient)
      .filter((word) => word.length > 2)
      .forEach((word) => keywords.add(word))
  })

  // Add tags and category
  recipe.tags.forEach((tag) => keywords.add(tag.toLowerCase()))
  keywords.add(recipe.category.toLowerCase())

  return Array.from(keywords)
}

/**
 * Highlight search terms in text
 */
const highlightSearchTerms = (text, searchTerms) => {
  let highlightedText = text
  searchTerms.forEach((term) => {
    const regex = new RegExp(`(${term})`, "gi")
    highlightedText = highlightedText.replace(regex, "<mark>$1</mark>")
  })
  return highlightedText
}

module.exports = {
  tokenizeText,
  calculateSimilarity,
  extractKeywords,
  highlightSearchTerms,
}
