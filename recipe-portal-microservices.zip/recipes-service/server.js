const express = require("express")
const cors = require("cors")
const jwt = require("jsonwebtoken")

const app = express()
const PORT = process.env.PORT || 3002
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// Middleware
app.use(cors())
app.use(express.json())

// Mock data - In-memory recipe storage
const recipes = [
  {
    id: 1,
    title: "Classic Spaghetti Carbonara",
    description: "A traditional Italian pasta dish with eggs, cheese, and pancetta",
    ingredients: [
      "400g spaghetti",
      "200g pancetta or guanciale",
      "4 large eggs",
      "100g Pecorino Romano cheese",
      "Black pepper",
      "Salt",
    ],
    instructions: [
      "Bring a large pot of salted water to boil and cook spaghetti according to package directions",
      "While pasta cooks, cut pancetta into small cubes and cook in a large skillet until crispy",
      "In a bowl, whisk together eggs, grated cheese, and black pepper",
      "Drain pasta, reserving 1 cup of pasta water",
      "Add hot pasta to the skillet with pancetta",
      "Remove from heat and quickly stir in egg mixture, adding pasta water as needed",
      "Serve immediately with extra cheese and black pepper",
    ],
    imageUrl: "https://images.unsplash.com/photo-1621996346565-e3dbc353d2e5?w=800&h=600&fit=crop",
    prepTime: 15,
    cookTime: 20,
    servings: 4,
    difficulty: "Medium",
    category: "Italian",
    tags: ["pasta", "italian", "traditional", "quick"],
    authorId: 2,
    authorName: "Gordon Ramsay",
    createdAt: "2024-01-15T10:00:00.000Z",
    updatedAt: "2024-01-15T10:00:00.000Z",
  },
  {
    id: 2,
    title: "Homemade Pizza Margherita",
    description: "Classic Italian pizza with tomato sauce, mozzarella, and fresh basil",
    ingredients: [
      "500g pizza dough",
      "200ml tomato sauce",
      "250g fresh mozzarella",
      "Fresh basil leaves",
      "Extra virgin olive oil",
      "Salt",
      "Black pepper",
    ],
    instructions: [
      "Preheat oven to 250°C (482°F)",
      "Roll out pizza dough on a floured surface",
      "Transfer to a pizza stone or baking sheet",
      "Spread tomato sauce evenly, leaving a border for the crust",
      "Tear mozzarella into pieces and distribute over sauce",
      "Drizzle with olive oil and season with salt and pepper",
      "Bake for 10-12 minutes until crust is golden and cheese is bubbly",
      "Top with fresh basil leaves before serving",
    ],
    imageUrl: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=800&h=600&fit=crop",
    prepTime: 20,
    cookTime: 12,
    servings: 2,
    difficulty: "Easy",
    category: "Italian",
    tags: ["pizza", "italian", "vegetarian", "homemade"],
    authorId: 1,
    authorName: "Admin User",
    createdAt: "2024-01-16T14:30:00.000Z",
    updatedAt: "2024-01-16T14:30:00.000Z",
  },
  {
    id: 3,
    title: "Chocolate Chip Cookies",
    description: "Soft and chewy chocolate chip cookies that are perfect for any occasion",
    ingredients: [
      "225g butter, softened",
      "200g brown sugar",
      "100g granulated sugar",
      "2 large eggs",
      "2 tsp vanilla extract",
      "350g all-purpose flour",
      "1 tsp baking soda",
      "1 tsp salt",
      "300g chocolate chips",
    ],
    instructions: [
      "Preheat oven to 190°C (375°F)",
      "Cream together butter and both sugars until light and fluffy",
      "Beat in eggs one at a time, then add vanilla",
      "In a separate bowl, whisk together flour, baking soda, and salt",
      "Gradually mix dry ingredients into wet ingredients",
      "Fold in chocolate chips",
      "Drop rounded tablespoons of dough onto ungreased baking sheets",
      "Bake for 9-11 minutes until edges are golden brown",
      "Cool on baking sheet for 5 minutes before transferring to wire rack",
    ],
    imageUrl: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=800&h=600&fit=crop",
    prepTime: 15,
    cookTime: 11,
    servings: 24,
    difficulty: "Easy",
    category: "Dessert",
    tags: ["cookies", "dessert", "chocolate", "baking"],
    authorId: 3,
    authorName: "Julia Child",
    createdAt: "2024-01-17T09:15:00.000Z",
    updatedAt: "2024-01-17T09:15:00.000Z",
  },
]

let nextRecipeId = 4

// Helper functions
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) {
    return res.status(401).json({
      error: "Access denied",
      message: "No token provided",
    })
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({
        error: "Invalid token",
        message: "Token is not valid or has expired",
      })
    }

    req.user = user
    next()
  })
}

const optionalAuth = (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (token) {
    jwt.verify(token, JWT_SECRET, (err, user) => {
      if (!err) {
        req.user = user
      }
    })
  }

  next()
}

// Routes

// Health check
app.get("/health", (req, res) => {
  res.json({
    status: "OK",
    service: "Recipes Service",
    timestamp: new Date().toISOString(),
  })
})

// Get all recipes
app.get("/api/recipes", optionalAuth, (req, res) => {
  try {
    const { category, difficulty, author, limit, offset } = req.query

    let filteredRecipes = [...recipes]

    // Apply filters
    if (category) {
      filteredRecipes = filteredRecipes.filter((recipe) => recipe.category.toLowerCase() === category.toLowerCase())
    }

    if (difficulty) {
      filteredRecipes = filteredRecipes.filter((recipe) => recipe.difficulty.toLowerCase() === difficulty.toLowerCase())
    }

    if (author) {
      filteredRecipes = filteredRecipes.filter((recipe) =>
        recipe.authorName.toLowerCase().includes(author.toLowerCase()),
      )
    }

    // Sort by creation date (newest first)
    filteredRecipes.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

    // Apply pagination
    const limitNum = Number.parseInt(limit) || 10
    const offsetNum = Number.parseInt(offset) || 0
    const paginatedRecipes = filteredRecipes.slice(offsetNum, offsetNum + limitNum)

    res.json({
      recipes: paginatedRecipes,
      total: filteredRecipes.length,
      limit: limitNum,
      offset: offsetNum,
    })
  } catch (error) {
    console.error("Get recipes error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get recipes",
    })
  }
})

// Get recipe by ID
app.get("/api/recipes/:id", optionalAuth, (req, res) => {
  try {
    const recipeId = Number.parseInt(req.params.id)
    const recipe = recipes.find((r) => r.id === recipeId)

    if (!recipe) {
      return res.status(404).json({
        error: "Recipe not found",
        message: "Recipe with this ID not found",
      })
    }

    res.json({
      recipe,
    })
  } catch (error) {
    console.error("Get recipe error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get recipe",
    })
  }
})

// Create new recipe
app.post("/api/recipes", authenticateToken, (req, res) => {
  try {
    const {
      title,
      description,
      ingredients,
      instructions,
      imageUrl,
      prepTime,
      cookTime,
      servings,
      difficulty,
      category,
      tags,
    } = req.body

    // Validation
    if (!title || !description || !ingredients || !instructions) {
      return res.status(400).json({
        error: "Validation error",
        message: "Title, description, ingredients, and instructions are required",
      })
    }

    if (!Array.isArray(ingredients) || !Array.isArray(instructions)) {
      return res.status(400).json({
        error: "Validation error",
        message: "Ingredients and instructions must be arrays",
      })
    }

    // Create new recipe
    const newRecipe = {
      id: nextRecipeId++,
      title,
      description,
      ingredients,
      instructions,
      imageUrl: imageUrl || "https://images.unsplash.com/photo-1546548970-71785318a17b?w=800&h=600&fit=crop",
      prepTime: Number.parseInt(prepTime) || 0,
      cookTime: Number.parseInt(cookTime) || 0,
      servings: Number.parseInt(servings) || 1,
      difficulty: difficulty || "Medium",
      category: category || "Other",
      tags: Array.isArray(tags) ? tags : [],
      authorId: req.user.id,
      authorName: `${req.user.firstName} ${req.user.lastName}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    recipes.push(newRecipe)

    res.status(201).json({
      message: "Recipe created successfully",
      recipe: newRecipe,
    })
  } catch (error) {
    console.error("Create recipe error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to create recipe",
    })
  }
})

// Update recipe
app.put("/api/recipes/:id", authenticateToken, (req, res) => {
  try {
    const recipeId = Number.parseInt(req.params.id)
    const recipeIndex = recipes.findIndex((r) => r.id === recipeId)

    if (recipeIndex === -1) {
      return res.status(404).json({
        error: "Recipe not found",
        message: "Recipe with this ID not found",
      })
    }

    // Check if user owns the recipe
    if (recipes[recipeIndex].authorId !== req.user.id) {
      return res.status(403).json({
        error: "Access denied",
        message: "You can only update your own recipes",
      })
    }

    const {
      title,
      description,
      ingredients,
      instructions,
      imageUrl,
      prepTime,
      cookTime,
      servings,
      difficulty,
      category,
      tags,
    } = req.body

    // Update recipe fields
    if (title) recipes[recipeIndex].title = title
    if (description) recipes[recipeIndex].description = description
    if (ingredients && Array.isArray(ingredients)) recipes[recipeIndex].ingredients = ingredients
    if (instructions && Array.isArray(instructions)) recipes[recipeIndex].instructions = instructions
    if (imageUrl) recipes[recipeIndex].imageUrl = imageUrl
    if (prepTime !== undefined) recipes[recipeIndex].prepTime = Number.parseInt(prepTime)
    if (cookTime !== undefined) recipes[recipeIndex].cookTime = Number.parseInt(cookTime)
    if (servings !== undefined) recipes[recipeIndex].servings = Number.parseInt(servings)
    if (difficulty) recipes[recipeIndex].difficulty = difficulty
    if (category) recipes[recipeIndex].category = category
    if (tags && Array.isArray(tags)) recipes[recipeIndex].tags = tags

    recipes[recipeIndex].updatedAt = new Date().toISOString()

    res.json({
      message: "Recipe updated successfully",
      recipe: recipes[recipeIndex],
    })
  } catch (error) {
    console.error("Update recipe error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to update recipe",
    })
  }
})

// Delete recipe
app.delete("/api/recipes/:id", authenticateToken, (req, res) => {
  try {
    const recipeId = Number.parseInt(req.params.id)
    const recipeIndex = recipes.findIndex((r) => r.id === recipeId)

    if (recipeIndex === -1) {
      return res.status(404).json({
        error: "Recipe not found",
        message: "Recipe with this ID not found",
      })
    }

    // Check if user owns the recipe
    if (recipes[recipeIndex].authorId !== req.user.id) {
      return res.status(403).json({
        error: "Access denied",
        message: "You can only delete your own recipes",
      })
    }

    recipes.splice(recipeIndex, 1)

    res.json({
      message: "Recipe deleted successfully",
    })
  } catch (error) {
    console.error("Delete recipe error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to delete recipe",
    })
  }
})

// Get recipes by author
app.get("/api/recipes/author/:authorId", optionalAuth, (req, res) => {
  try {
    const authorId = Number.parseInt(req.params.authorId)
    const authorRecipes = recipes.filter((recipe) => recipe.authorId === authorId)

    // Sort by creation date (newest first)
    authorRecipes.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

    res.json({
      recipes: authorRecipes,
      total: authorRecipes.length,
      authorId,
    })
  } catch (error) {
    console.error("Get author recipes error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get author recipes",
    })
  }
})

// Get recipe categories
app.get("/api/recipes/meta/categories", (req, res) => {
  try {
    const categories = [...new Set(recipes.map((recipe) => recipe.category))].sort()
    res.json({
      categories,
    })
  } catch (error) {
    console.error("Get categories error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get categories",
    })
  }
})

// Get recipe tags
app.get("/api/recipes/meta/tags", (req, res) => {
  try {
    const allTags = recipes.flatMap((recipe) => recipe.tags)
    const uniqueTags = [...new Set(allTags)].sort()
    res.json({
      tags: uniqueTags,
    })
  } catch (error) {
    console.error("Get tags error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get tags",
    })
  }
})

// Error handler
app.use((err, req, res, next) => {
  console.error("Recipes service error:", err)
  res.status(500).json({
    error: "Internal Server Error",
    message: "Something went wrong in the Recipes service",
  })
})

// 404 handler
app.use("*", (req, res) => {
  res.status(404).json({
    error: "Not Found",
    message: `Route ${req.originalUrl} not found in Recipes service`,
  })
})

app.listen(PORT, () => {
  console.log(`🍳 Recipes Service running on port ${PORT}`)
  console.log(`📋 Available endpoints:`)
  console.log(`   GET /api/recipes - Get all recipes (with filters)`)
  console.log(`   GET /api/recipes/:id - Get recipe by ID`)
  console.log(`   POST /api/recipes - Create recipe (auth required)`)
  console.log(`   PUT /api/recipes/:id - Update recipe (auth required)`)
  console.log(`   DELETE /api/recipes/:id - Delete recipe (auth required)`)
  console.log(`   GET /api/recipes/author/:authorId - Get recipes by author`)
  console.log(`   GET /api/recipes/meta/categories - Get all categories`)
  console.log(`   GET /api/recipes/meta/tags - Get all tags`)
  console.log(`\n📊 Mock data: ${recipes.length} recipes loaded`)
})
