// Additional mock ratings and comments data
const mockRatings = [
  {
    id: 4,
    recipeId: 3,
    userId: 2,
    userName: "Gordon Ramsay",
    userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    rating: 4,
    createdAt: "2024-01-17T14:00:00.000Z",
    updatedAt: "2024-01-17T14:00:00.000Z",
  },
  {
    id: 5,
    recipeId: 2,
    userId: 1,
    userName: "Admin User",
    userAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    rating: 5,
    createdAt: "2024-01-16T18:00:00.000Z",
    updatedAt: "2024-01-16T18:00:00.000Z",
  },
]

const mockComments = [
  {
    id: 5,
    recipeId: 2,
    userId: 1,
    userName: "Admin User",
    userAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    comment: "This pizza turned out amazing! The crust was perfectly crispy and the toppings were fresh.",
    createdAt: "2024-01-16T18:05:00.000Z",
    updatedAt: "2024-01-16T18:05:00.000Z",
  },
  {
    id: 6,
    recipeId: 3,
    userId: 2,
    userName: "Gordon Ramsay",
    userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    comment: "Good cookies, but I'd suggest using brown butter for extra flavor depth.",
    createdAt: "2024-01-17T14:05:00.000Z",
    updatedAt: "2024-01-17T14:05:00.000Z",
  },
]

module.exports = { mockRatings, mockComments }
