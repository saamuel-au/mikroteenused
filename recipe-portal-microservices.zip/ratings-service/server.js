const express = require("express")
const cors = require("cors")
const jwt = require("jsonwebtoken")

const app = express()
const PORT = process.env.PORT || 3004
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// Middleware
app.use(cors())
app.use(express.json())

// Mock data - In-memory storage
const ratings = [
  {
    id: 1,
    recipeId: 1,
    userId: 2,
    userName: "Gordon Ramsay",
    userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    rating: 5,
    createdAt: "2024-01-15T11:00:00.000Z",
    updatedAt: "2024-01-15T11:00:00.000Z",
  },
  {
    id: 2,
    recipeId: 1,
    userId: 1,
    userName: "Admin User",
    userAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    rating: 4,
    createdAt: "2024-01-15T15:30:00.000Z",
    updatedAt: "2024-01-15T15:30:00.000Z",
  },
  {
    id: 3,
    recipeId: 2,
    userId: 3,
    userName: "Julia Child",
    userAvatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
    rating: 5,
    createdAt: "2024-01-16T16:00:00.000Z",
    updatedAt: "2024-01-16T16:00:00.000Z",
  },
]

const comments = [
  {
    id: 1,
    recipeId: 1,
    userId: 2,
    userName: "Gordon Ramsay",
    userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    comment: "Absolutely brilliant! This is how carbonara should be made. Perfect technique.",
    createdAt: "2024-01-15T11:05:00.000Z",
    updatedAt: "2024-01-15T11:05:00.000Z",
  },
  {
    id: 2,
    recipeId: 1,
    userId: 1,
    userName: "Admin User",
    userAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    comment: "Great recipe! I added a bit more black pepper and it was perfect.",
    createdAt: "2024-01-15T15:35:00.000Z",
    updatedAt: "2024-01-15T15:35:00.000Z",
  },
  {
    id: 3,
    recipeId: 2,
    userId: 3,
    userName: "Julia Child",
    userAvatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
    comment: "Love this pizza recipe! The dough came out perfectly crispy.",
    createdAt: "2024-01-16T16:05:00.000Z",
    updatedAt: "2024-01-16T16:05:00.000Z",
  },
  {
    id: 4,
    recipeId: 3,
    userId: 1,
    userName: "Admin User",
    userAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    comment: "These cookies are amazing! My kids loved them.",
    createdAt: "2024-01-17T10:00:00.000Z",
    updatedAt: "2024-01-17T10:00:00.000Z",
  },
]

let nextRatingId = 4
let nextCommentId = 5

// Helper functions
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) {
    return res.status(401).json({
      error: "Access denied",
      message: "No token provided",
    })
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({
        error: "Invalid token",
        message: "Token is not valid or has expired",
      })
    }

    req.user = user
    next()
  })
}

const calculateAverageRating = (recipeId) => {
  const recipeRatings = ratings.filter((r) => r.recipeId === recipeId)
  if (recipeRatings.length === 0) return 0

  const sum = recipeRatings.reduce((acc, rating) => acc + rating.rating, 0)
  return Math.round((sum / recipeRatings.length) * 10) / 10 // Round to 1 decimal place
}

// Routes

// Health check
app.get("/health", (req, res) => {
  res.json({
    status: "OK",
    service: "Ratings Service",
    timestamp: new Date().toISOString(),
  })
})

// Get ratings for a recipe
app.get("/api/ratings/recipe/:recipeId", (req, res) => {
  try {
    const recipeId = Number.parseInt(req.params.recipeId)
    const recipeRatings = ratings.filter((r) => r.recipeId === recipeId)

    // Sort by creation date (newest first)
    recipeRatings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

    const averageRating = calculateAverageRating(recipeId)

    res.json({
      recipeId,
      ratings: recipeRatings,
      averageRating,
      totalRatings: recipeRatings.length,
    })
  } catch (error) {
    console.error("Get ratings error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get ratings",
    })
  }
})

// Add or update rating
app.post("/api/ratings", authenticateToken, (req, res) => {
  try {
    const { recipeId, rating } = req.body

    // Validation
    if (!recipeId || !rating) {
      return res.status(400).json({
        error: "Validation error",
        message: "Recipe ID and rating are required",
      })
    }

    if (rating < 1 || rating > 5) {
      return res.status(400).json({
        error: "Validation error",
        message: "Rating must be between 1 and 5",
      })
    }

    // Check if user already rated this recipe
    const existingRatingIndex = ratings.findIndex((r) => r.recipeId === recipeId && r.userId === req.user.id)

    if (existingRatingIndex !== -1) {
      // Update existing rating
      ratings[existingRatingIndex].rating = rating
      ratings[existingRatingIndex].updatedAt = new Date().toISOString()

      const averageRating = calculateAverageRating(recipeId)

      res.json({
        message: "Rating updated successfully",
        rating: ratings[existingRatingIndex],
        averageRating,
      })
    } else {
      // Create new rating
      const newRating = {
        id: nextRatingId++,
        recipeId,
        userId: req.user.id,
        userName: `${req.user.firstName} ${req.user.lastName}`,
        userAvatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&crop=face`,
        rating,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      ratings.push(newRating)

      const averageRating = calculateAverageRating(recipeId)

      res.status(201).json({
        message: "Rating added successfully",
        rating: newRating,
        averageRating,
      })
    }
  } catch (error) {
    console.error("Add rating error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to add rating",
    })
  }
})

// Delete rating
app.delete("/api/ratings/:id", authenticateToken, (req, res) => {
  try {
    const ratingId = Number.parseInt(req.params.id)
    const ratingIndex = ratings.findIndex((r) => r.id === ratingId)

    if (ratingIndex === -1) {
      return res.status(404).json({
        error: "Rating not found",
        message: "Rating with this ID not found",
      })
    }

    // Check if user owns the rating
    if (ratings[ratingIndex].userId !== req.user.id) {
      return res.status(403).json({
        error: "Access denied",
        message: "You can only delete your own ratings",
      })
    }

    const recipeId = ratings[ratingIndex].recipeId
    ratings.splice(ratingIndex, 1)

    const averageRating = calculateAverageRating(recipeId)

    res.json({
      message: "Rating deleted successfully",
      averageRating,
    })
  } catch (error) {
    console.error("Delete rating error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to delete rating",
    })
  }
})

// Get comments for a recipe
app.get("/api/ratings/comments/:recipeId", (req, res) => {
  try {
    const recipeId = Number.parseInt(req.params.recipeId)
    const { limit, offset } = req.query

    const recipeComments = comments.filter((c) => c.recipeId === recipeId)

    // Sort by creation date (newest first)
    recipeComments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

    // Apply pagination
    const limitNum = Number.parseInt(limit) || 10
    const offsetNum = Number.parseInt(offset) || 0
    const paginatedComments = recipeComments.slice(offsetNum, offsetNum + limitNum)

    res.json({
      recipeId,
      comments: paginatedComments,
      total: recipeComments.length,
      limit: limitNum,
      offset: offsetNum,
    })
  } catch (error) {
    console.error("Get comments error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get comments",
    })
  }
})

// Add comment
app.post("/api/ratings/comments", authenticateToken, (req, res) => {
  try {
    const { recipeId, comment } = req.body

    // Validation
    if (!recipeId || !comment) {
      return res.status(400).json({
        error: "Validation error",
        message: "Recipe ID and comment are required",
      })
    }

    if (comment.trim().length < 3) {
      return res.status(400).json({
        error: "Validation error",
        message: "Comment must be at least 3 characters long",
      })
    }

    if (comment.length > 1000) {
      return res.status(400).json({
        error: "Validation error",
        message: "Comment must be less than 1000 characters",
      })
    }

    // Create new comment
    const newComment = {
      id: nextCommentId++,
      recipeId,
      userId: req.user.id,
      userName: `${req.user.firstName} ${req.user.lastName}`,
      userAvatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&crop=face`,
      comment: comment.trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    comments.push(newComment)

    res.status(201).json({
      message: "Comment added successfully",
      comment: newComment,
    })
  } catch (error) {
    console.error("Add comment error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to add comment",
    })
  }
})

// Update comment
app.put("/api/ratings/comments/:id", authenticateToken, (req, res) => {
  try {
    const commentId = Number.parseInt(req.params.id)
    const { comment } = req.body
    const commentIndex = comments.findIndex((c) => c.id === commentId)

    if (commentIndex === -1) {
      return res.status(404).json({
        error: "Comment not found",
        message: "Comment with this ID not found",
      })
    }

    // Check if user owns the comment
    if (comments[commentIndex].userId !== req.user.id) {
      return res.status(403).json({
        error: "Access denied",
        message: "You can only update your own comments",
      })
    }

    // Validation
    if (!comment || comment.trim().length < 3) {
      return res.status(400).json({
        error: "Validation error",
        message: "Comment must be at least 3 characters long",
      })
    }

    if (comment.length > 1000) {
      return res.status(400).json({
        error: "Validation error",
        message: "Comment must be less than 1000 characters",
      })
    }

    // Update comment
    comments[commentIndex].comment = comment.trim()
    comments[commentIndex].updatedAt = new Date().toISOString()

    res.json({
      message: "Comment updated successfully",
      comment: comments[commentIndex],
    })
  } catch (error) {
    console.error("Update comment error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to update comment",
    })
  }
})

// Delete comment
app.delete("/api/ratings/comments/:id", authenticateToken, (req, res) => {
  try {
    const commentId = Number.parseInt(req.params.id)
    const commentIndex = comments.findIndex((c) => c.id === commentId)

    if (commentIndex === -1) {
      return res.status(404).json({
        error: "Comment not found",
        message: "Comment with this ID not found",
      })
    }

    // Check if user owns the comment
    if (comments[commentIndex].userId !== req.user.id) {
      return res.status(403).json({
        error: "Access denied",
        message: "You can only delete your own comments",
      })
    }

    comments.splice(commentIndex, 1)

    res.json({
      message: "Comment deleted successfully",
    })
  } catch (error) {
    console.error("Delete comment error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to delete comment",
    })
  }
})

// Get user's ratings
app.get("/api/ratings/user/:userId", (req, res) => {
  try {
    const userId = Number.parseInt(req.params.userId)
    const userRatings = ratings.filter((r) => r.userId === userId)

    // Sort by creation date (newest first)
    userRatings.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

    res.json({
      userId,
      ratings: userRatings,
      total: userRatings.length,
    })
  } catch (error) {
    console.error("Get user ratings error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get user ratings",
    })
  }
})

// Get recipe statistics
app.get("/api/ratings/stats/:recipeId", (req, res) => {
  try {
    const recipeId = Number.parseInt(req.params.recipeId)
    const recipeRatings = ratings.filter((r) => r.recipeId === recipeId)
    const recipeComments = comments.filter((c) => c.recipeId === recipeId)

    // Calculate rating distribution
    const ratingDistribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }
    recipeRatings.forEach((rating) => {
      ratingDistribution[rating.rating]++
    })

    const averageRating = calculateAverageRating(recipeId)

    res.json({
      recipeId,
      averageRating,
      totalRatings: recipeRatings.length,
      totalComments: recipeComments.length,
      ratingDistribution,
    })
  } catch (error) {
    console.error("Get recipe stats error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get recipe statistics",
    })
  }
})

// Error handler
app.use((err, req, res, next) => {
  console.error("Ratings service error:", err)
  res.status(500).json({
    error: "Internal Server Error",
    message: "Something went wrong in the Ratings service",
  })
})

// 404 handler
app.use("*", (req, res) => {
  res.status(404).json({
    error: "Not Found",
    message: `Route ${req.originalUrl} not found in Ratings service`,
  })
})

app.listen(PORT, () => {
  console.log(`⭐ Ratings Service running on port ${PORT}`)
  console.log(`📋 Available endpoints:`)
  console.log(`   GET /api/ratings/recipe/:recipeId - Get ratings for recipe`)
  console.log(`   POST /api/ratings - Add/update rating (auth required)`)
  console.log(`   DELETE /api/ratings/:id - Delete rating (auth required)`)
  console.log(`   GET /api/ratings/comments/:recipeId - Get comments for recipe`)
  console.log(`   POST /api/ratings/comments - Add comment (auth required)`)
  console.log(`   PUT /api/ratings/comments/:id - Update comment (auth required)`)
  console.log(`   DELETE /api/ratings/comments/:id - Delete comment (auth required)`)
  console.log(`   GET /api/ratings/user/:userId - Get user ratings`)
  console.log(`   GET /api/ratings/stats/:recipeId - Get recipe statistics`)
  console.log(`\n📊 Mock data: ${ratings.length} ratings, ${comments.length} comments loaded`)
})
