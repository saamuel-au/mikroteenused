const express = require("express")
const cors = require("cors")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")

const app = express()
const PORT = process.env.PORT || 3001
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

// Middleware
app.use(cors())
app.use(express.json())

// Mock data - In-memory user storage
const users = [
  {
    id: 1,
    email: "admin@example.com",
    password: "$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi", // password
    firstName: "Admin",
    lastName: "User",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    bio: "System administrator",
    createdAt: "2024-01-01T00:00:00.000Z",
    updatedAt: "2024-01-01T00:00:00.000Z",
  },
  {
    id: 2,
    email: "chef@example.com",
    password: "$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi", // password
    firstName: "Gordon",
    lastName: "Ramsay",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    bio: "Professional chef and cookbook author",
    createdAt: "2024-01-02T00:00:00.000Z",
    updatedAt: "2024-01-02T00:00:00.000Z",
  },
]

let nextUserId = 3

// Helper functions
const generateToken = (user) => {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
    },
    JWT_SECRET,
    { expiresIn: "24h" },
  )
}

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) {
    return res.status(401).json({
      error: "Access denied",
      message: "No token provided",
    })
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({
        error: "Invalid token",
        message: "Token is not valid or has expired",
      })
    }

    req.user = user
    next()
  })
}

// Routes

// Health check
app.get("/health", (req, res) => {
  res.json({
    status: "OK",
    service: "Users Service",
    timestamp: new Date().toISOString(),
  })
})

// Register new user
app.post("/api/users/register", async (req, res) => {
  try {
    const { email, password, firstName, lastName, bio } = req.body

    // Validation
    if (!email || !password || !firstName || !lastName) {
      return res.status(400).json({
        error: "Validation error",
        message: "Email, password, first name, and last name are required",
      })
    }

    // Check if user already exists
    const existingUser = users.find((user) => user.email === email)
    if (existingUser) {
      return res.status(409).json({
        error: "User exists",
        message: "User with this email already exists",
      })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Create new user
    const newUser = {
      id: nextUserId++,
      email,
      password: hashedPassword,
      firstName,
      lastName,
      avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&crop=face`,
      bio: bio || "",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    users.push(newUser)

    // Generate token
    const token = generateToken(newUser)

    // Return user without password
    const { password: _, ...userWithoutPassword } = newUser

    res.status(201).json({
      message: "User registered successfully",
      user: userWithoutPassword,
      token,
    })
  } catch (error) {
    console.error("Registration error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to register user",
    })
  }
})

// Login user
app.post("/api/users/login", async (req, res) => {
  try {
    const { email, password } = req.body

    // Validation
    if (!email || !password) {
      return res.status(400).json({
        error: "Validation error",
        message: "Email and password are required",
      })
    }

    // Find user
    const user = users.find((u) => u.email === email)
    if (!user) {
      return res.status(401).json({
        error: "Authentication failed",
        message: "Invalid email or password",
      })
    }

    // Check password
    const isPasswordValid = await bcrypt.compare(password, user.password)
    if (!isPasswordValid) {
      return res.status(401).json({
        error: "Authentication failed",
        message: "Invalid email or password",
      })
    }

    // Generate token
    const token = generateToken(user)

    // Return user without password
    const { password: _, ...userWithoutPassword } = user

    res.json({
      message: "Login successful",
      user: userWithoutPassword,
      token,
    })
  } catch (error) {
    console.error("Login error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to login",
    })
  }
})

// Get user profile
app.get("/api/users/profile", authenticateToken, (req, res) => {
  try {
    const user = users.find((u) => u.id === req.user.id)
    if (!user) {
      return res.status(404).json({
        error: "User not found",
        message: "User profile not found",
      })
    }

    // Return user without password
    const { password: _, ...userWithoutPassword } = user

    res.json({
      user: userWithoutPassword,
    })
  } catch (error) {
    console.error("Profile error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get user profile",
    })
  }
})

// Update user profile
app.put("/api/users/profile", authenticateToken, (req, res) => {
  try {
    const { firstName, lastName, bio, avatar } = req.body
    const userIndex = users.findIndex((u) => u.id === req.user.id)

    if (userIndex === -1) {
      return res.status(404).json({
        error: "User not found",
        message: "User profile not found",
      })
    }

    // Update user data
    if (firstName) users[userIndex].firstName = firstName
    if (lastName) users[userIndex].lastName = lastName
    if (bio !== undefined) users[userIndex].bio = bio
    if (avatar) users[userIndex].avatar = avatar
    users[userIndex].updatedAt = new Date().toISOString()

    // Return updated user without password
    const { password: _, ...userWithoutPassword } = users[userIndex]

    res.json({
      message: "Profile updated successfully",
      user: userWithoutPassword,
    })
  } catch (error) {
    console.error("Profile update error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to update profile",
    })
  }
})

// Get all users (for development/testing)
app.get("/api/users", (req, res) => {
  const usersWithoutPasswords = users.map(({ password, ...user }) => user)
  res.json({
    users: usersWithoutPasswords,
    total: users.length,
  })
})

// Get user by ID
app.get("/api/users/:id", (req, res) => {
  try {
    const userId = Number.parseInt(req.params.id)
    const user = users.find((u) => u.id === userId)

    if (!user) {
      return res.status(404).json({
        error: "User not found",
        message: "User with this ID not found",
      })
    }

    // Return user without password
    const { password: _, ...userWithoutPassword } = user

    res.json({
      user: userWithoutPassword,
    })
  } catch (error) {
    console.error("Get user error:", error)
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to get user",
    })
  }
})

// Error handler
app.use((err, req, res, next) => {
  console.error("Users service error:", err)
  res.status(500).json({
    error: "Internal Server Error",
    message: "Something went wrong in the Users service",
  })
})

// 404 handler
app.use("*", (req, res) => {
  res.status(404).json({
    error: "Not Found",
    message: `Route ${req.originalUrl} not found in Users service`,
  })
})

app.listen(PORT, () => {
  console.log(`👥 Users Service running on port ${PORT}`)
  console.log(`📋 Available endpoints:`)
  console.log(`   POST /api/users/register - Register new user`)
  console.log(`   POST /api/users/login - User login`)
  console.log(`   GET /api/users/profile - Get user profile (auth required)`)
  console.log(`   PUT /api/users/profile - Update profile (auth required)`)
  console.log(`   GET /api/users - Get all users`)
  console.log(`   GET /api/users/:id - Get user by ID`)
  console.log(`\n🔐 Test credentials:`)
  console.log(`   admin@example.com / password`)
  console.log(`   chef@example.com / password`)
})
