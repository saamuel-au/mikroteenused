// Mock user data for development
const bcrypt = require("bcryptjs")

const createMockUsers = async () => {
  const hashedPassword = await bcrypt.hash("password", 10)

  return [
    {
      id: 1,
      email: "admin@example.com",
      password: hashedPassword,
      firstName: "Admin",
      lastName: "User",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      bio: "System administrator and recipe enthusiast",
      createdAt: "2024-01-01T00:00:00.000Z",
      updatedAt: "2024-01-01T00:00:00.000Z",
    },
    {
      id: 2,
      email: "chef@example.com",
      password: hashedPassword,
      firstName: "Gordon",
      lastName: "Ramsay",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      bio: "Professional chef and cookbook author. Passionate about creating amazing recipes.",
      createdAt: "2024-01-02T00:00:00.000Z",
      updatedAt: "2024-01-02T00:00:00.000Z",
    },
    {
      id: 3,
      email: "baker@example.com",
      password: hashedPassword,
      firstName: "Julia",
      lastName: "Child",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      bio: "Master baker specializing in French pastries and traditional breads.",
      createdAt: "2024-01-03T00:00:00.000Z",
      updatedAt: "2024-01-03T00:00:00.000Z",
    },
  ]
}

module.exports = { createMockUsers }
