"use client"

import Link from "next/link"
import { useAuth } from "@/contexts/AuthContext"

export default function Header() {
  const { user, logout } = useAuth()

  return (
    <header className="bg-card border-b border-border">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-primary">
            Retseptide Portaal
          </Link>

          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-foreground hover:text-primary">
              Avaleht
            </Link>
            <Link href="/recipes" className="text-foreground hover:text-primary">
              Retseptid
            </Link>
            <Link href="/search" className="text-foreground hover:text-primary">
              Otsing
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-4">
                <span className="text-foreground">Tere, {user.name}!</span>
                <button
                  onClick={logout}
                  className="bg-secondary text-secondary-foreground px-4 py-2 rounded-md hover:bg-secondary/80"
                >
                  Logi välja
                </button>
              </div>
            ) : (
              <Link
                href="/login"
                className="bg-primary text-primary-foreground px-4 py-2 rounded-md hover:bg-primary/90"
              >
                Logi sisse
              </Link>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
